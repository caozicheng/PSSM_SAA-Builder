﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public string path = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void input_btn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowDialog();
            path = folderDlg.SelectedPath;//声明PSSM文件所在路径
            DirectoryInfo dir = new DirectoryInfo(path);
            List<string> list = new List<string>();
            FileInfo[] files = dir.GetFiles();//返回当前文件夹里文件目录
            foreach (FileInfo item in files) //将每个后缀为txt的文件添加到list集合里
            {
                if (item.Extension == ".txt")
                {
                    combo_box.Items.Add(item);//获取文件完整的路径
                }
            }
            combo_box.SelectedIndex = 0;
        }

        private void output_btn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowDialog();
            output_txt.Text = folderDlg.SelectedPath;
        }

        private void run_btn_Click(object sender, EventArgs e)
        {
            string item = path + "\\" + combo_box.SelectedItem.ToString();
            double[] result = new double[1600];
            double[] sum = new double[20];
            //string[] pseChars = new string[] { "A", "R", "N", "D", "C", "Q", "E", "G", "H", "I", "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V" };//存放20个氨基酸
            int rowNum = 0;//用来记录读取到第几行
            int j;//用来表示第j列
            string sLine = "";
            int rowSum = 0;//文件里总行数              
            double FP = 0.25;
            double maxPSSM = 0;
            double minPSSM = 0;
            int[,] segNum = new int[20, 4];//分段后的个数

            foreach (string line in File.ReadLines(item))
            {
                rowSum++;//计算文件中总行数
            }

            double[,] originalPSSM = new double[rowSum, 20];//存储初始PSSM矩阵
            double[,] normalizPSSM = new double[rowSum, 20];//存储归一化的PSSM数据
            string[] sequence = new string[rowSum];
            double segSum = 0;

            StreamReader objReader = new StreamReader(item);

            while (sLine != null && rowNum < rowSum)
            {
                sLine = objReader.ReadLine().Trim();//读取每行数据去除首尾空格
                char[] ch = new char[] { ' ' };//去掉字符串中的空格
                string[] s = sLine.Split(ch, StringSplitOptions.RemoveEmptyEntries);
                sequence[rowNum] = Convert.ToString(s[0]);
                for (j = 0; j < 20; j++)
                {
                    originalPSSM[rowNum, j] = Convert.ToInt32(s[j + 1]);
                }
                rowNum++;
            }

            //求原PSSM矩阵里最大值和最小值，并归一化PSSM
            for (j = 0; j < 20; j++)
            {
                maxPSSM = originalPSSM[0, 0];
                minPSSM = originalPSSM[0, 0];
                for (int i = 0; i < rowSum; i++)
                {
                    if (originalPSSM[i, j] > maxPSSM)
                    {
                        maxPSSM = originalPSSM[i, j];
                    }
                    if (originalPSSM[i, j] < minPSSM)
                    {
                        minPSSM = originalPSSM[i, j];
                    }
                }
            }
            for (j = 0; j < 20; j++)
            {
                for (int i = 0; i < rowSum; i++)
                {
                    normalizPSSM[i, j] = (originalPSSM[i, j] - minPSSM) / (maxPSSM - minPSSM);
                }
            }
            for (j = 0; j < 20; j++)
            {
                for (int i = 0; i < rowSum; i++)
                {
                    sum[j] = sum[j] + normalizPSSM[i, j];
                }
            }

            //PSSM-SAC:有参数FP=5,10,25,这里取25          
            for (j = 0; j < 20; j++)
            {
                //存储第1段小于或等于第j列总和的FP%的个数
                for (int i = 0; i < rowSum; i++)
                {
                    segSum = segSum + normalizPSSM[i, j];
                    if (segSum == sum[j] * FP)
                    {
                        segNum[j, 0] = i;
                        i = rowSum;
                        segSum = 0;
                    }
                    if (segSum > sum[j] * FP)
                    {
                        segNum[j, 0] = i - 1;
                        i = rowSum;
                        segSum = 0;
                    }
                }
                //存储第2段小于或等于第j列总和的2*FP%的个数
                for (int i = segNum[j, 0] + 1; i < rowSum; i++)
                {
                    segSum = segSum + normalizPSSM[i, j];
                    if (segSum == sum[j] * FP)
                    {
                        segNum[j, 1] = i;
                        i = rowSum;
                        segSum = 0;
                    }
                    if (segSum > sum[j] * FP)
                    {
                        segNum[j, 1] = i - 1;
                        i = rowSum;
                        segSum = 0;
                    }
                }
                //存储第3段小于或等于第j列总和的FP%的个数，从最后一行开始
                for (int i = rowSum - 1; i > -1; i--)
                {
                    segSum = segSum + normalizPSSM[i, j];
                    if (segSum == sum[j] * FP)
                    {
                        segNum[j, 2] = i;
                        i = -1;
                        segSum = 0;
                    }
                    if (segSum > sum[j] * FP)
                    {
                        segNum[j, 2] = i + 1;
                        i = -1;
                        segSum = 0;
                    }
                }
                //存储第4段小于或等于第j列总和的2*FP%的个数，从最后一行开始
                for (int i = segNum[j, 2] - 1; i > -1; i--)
                {
                    segSum = segSum + normalizPSSM[i, j];
                    if (segSum == sum[j] * FP)
                    {
                        segNum[j, 3] = i;
                        i = -1;
                        segSum = 0;
                    }
                    if (segSum > sum[j] * FP)
                    {
                        segNum[j, 3] = i + 1;
                        i = -1;
                        segSum = 0;
                    }
                }
            }

            for (j = 0; j < 20; j++)
            {

                for (int p = 0; p <= segNum[j, 0]; p++)
                {
                    switch (sequence[p])
                    {
                        case "A":
                            result[80 * j] = result[80 * j] + 1;
                            break;
                        case "R":
                            result[80 * j + 1] = result[80 * j + 1] + 1;
                            break;
                        case "N":
                            result[80 * j + 2] = result[80 * j + 2] + 1;
                            break;
                        case "D":
                            result[80 * j + 3] = result[80 * j + 3] + 1;
                            break;
                        case "C":
                            result[80 * j + 4] = result[80 * j + 4] + 1;
                            break;
                        case "Q":
                            result[80 * j + 5] = result[80 * j + 5] + 1;
                            break;
                        case "E":
                            result[80 * j + 6] = result[80 * j + 6] + 1;
                            break;
                        case "G":
                            result[80 * j + 7] = result[80 * j + 7] + 1;
                            break;
                        case "H":
                            result[80 * j + 8] = result[80 * j + 8] + 1;
                            break;
                        case "I":
                            result[80 * j + 9] = result[80 * j + 9] + 1;
                            break;
                        case "L":
                            result[80 * j + 10] = result[80 * j + 10] + 1;
                            break;
                        case "K":
                            result[80 * j + 11] = result[80 * j + 11] + 1;
                            break;
                        case "M":
                            result[80 * j + 12] = result[80 * j + 12] + 1;
                            break;
                        case "F":
                            result[80 * j + 13] = result[80 * j + 13] + 1;
                            break;
                        case "P":
                            result[80 * j + 14] = result[80 * j + 14] + 1;
                            break;
                        case "S":
                            result[80 * j + 15] = result[80 * j + 15] + 1;
                            break;
                        case "T":
                            result[80 * j + 16] = result[80 * j + 16] + 1;
                            break;
                        case "W":
                            result[80 * j + 17] = result[80 * j + 17] + 1;
                            break;
                        case "Y":
                            result[80 * j + 18] = result[80 * j + 18] + 1;
                            break;
                        case "V":
                            result[80 * j + 19] = result[80 * j + 19] + 1;
                            break;
                    }
                }
                for (int p = segNum[j, 0] + 1; p <= segNum[j, 1]; p++)
                {
                    switch (sequence[p])
                    {
                        case "A":
                            result[80 * j + 20] = result[80 * j + 20] + 1;
                            break;
                        case "R":
                            result[80 * j + 21] = result[80 * j + 21] + 1;
                            break;
                        case "N":
                            result[80 * j + 22] = result[80 * j + 22] + 1;
                            break;
                        case "D":
                            result[80 * j + 23] = result[80 * j + 23] + 1;
                            break;
                        case "C":
                            result[80 * j + 24] = result[80 * j + 24] + 1;
                            break;
                        case "Q":
                            result[80 * j + 25] = result[80 * j + 25] + 1;
                            break;
                        case "E":
                            result[80 * j + 26] = result[80 * j + 26] + 1;
                            break;
                        case "G":
                            result[80 * j + 27] = result[80 * j + 27] + 1;
                            break;
                        case "H":
                            result[80 * j + 28] = result[80 * j + 28] + 1;
                            break;
                        case "I":
                            result[80 * j + 29] = result[80 * j + 29] + 1;
                            break;
                        case "L":
                            result[80 * j + 30] = result[80 * j + 30] + 1;
                            break;
                        case "K":
                            result[80 * j + 31] = result[80 * j + 31] + 1;
                            break;
                        case "M":
                            result[80 * j + 32] = result[80 * j + 32] + 1;
                            break;
                        case "F":
                            result[80 * j + 33] = result[80 * j + 33] + 1;
                            break;
                        case "P":
                            result[80 * j + 34] = result[80 * j + 34] + 1;
                            break;
                        case "S":
                            result[80 * j + 35] = result[80 * j + 35] + 1;
                            break;
                        case "T":
                            result[80 * j + 36] = result[80 * j + 36] + 1;
                            break;
                        case "W":
                            result[80 * j + 37] = result[80 * j + 37] + 1;
                            break;
                        case "Y":
                            result[80 * j + 38] = result[80 * j + 38] + 1;
                            break;
                        case "V":
                            result[80 * j + 39] = result[80 * j + 39] + 1;
                            break;
                    }
                }
                for (int p = rowSum - 1; p >= segNum[j, 2]; p--)
                {
                    switch (sequence[p])
                    {
                        case "A":
                            result[80 * j + 40] = result[80 * j + 40] + 1;
                            break;
                        case "R":
                            result[80 * j + 41] = result[80 * j + 41] + 1;
                            break;
                        case "N":
                            result[80 * j + 42] = result[80 * j + 42] + 1;
                            break;
                        case "D":
                            result[80 * j + 43] = result[80 * j + 43] + 1;
                            break;
                        case "C":
                            result[80 * j + 44] = result[80 * j + 44] + 1;
                            break;
                        case "Q":
                            result[80 * j + 45] = result[80 * j + 45] + 1;
                            break;
                        case "E":
                            result[80 * j + 46] = result[80 * j + 46] + 1;
                            break;
                        case "G":
                            result[80 * j + 47] = result[80 * j + 47] + 1;
                            break;
                        case "H":
                            result[80 * j + 48] = result[80 * j + 48] + 1;
                            break;
                        case "I":
                            result[80 * j + 49] = result[80 * j + 49] + 1;
                            break;
                        case "L":
                            result[80 * j + 50] = result[80 * j + 50] + 1;
                            break;
                        case "K":
                            result[80 * j + 51] = result[80 * j + 51] + 1;
                            break;
                        case "M":
                            result[80 * j + 52] = result[80 * j + 52] + 1;
                            break;
                        case "F":
                            result[80 * j + 53] = result[80 * j + 53] + 1;
                            break;
                        case "P":
                            result[80 * j + 54] = result[80 * j + 54] + 1;
                            break;
                        case "S":
                            result[80 * j + 55] = result[80 * j + 55] + 1;
                            break;
                        case "T":
                            result[80 * j + 56] = result[80 * j + 56] + 1;
                            break;
                        case "W":
                            result[80 * j + 57] = result[80 * j + 57] + 1;
                            break;
                        case "Y":
                            result[80 * j + 58] = result[80 * j + 58] + 1;
                            break;
                        case "V":
                            result[80 * j + 59] = result[80 * j + 59] + 1;
                            break;
                    }
                }
                for (int p = segNum[j, 2] - 1; p >= segNum[j, 3]; p--)
                {
                    switch (sequence[p])
                    {
                        case "A":
                            result[80 * j + 60] = result[80 * j + 60] + 1;
                            break;
                        case "R":
                            result[80 * j + 61] = result[80 * j + 61] + 1;
                            break;
                        case "N":
                            result[80 * j + 62] = result[80 * j + 62] + 1;
                            break;
                        case "D":
                            result[80 * j + 63] = result[80 * j + 63] + 1;
                            break;
                        case "C":
                            result[80 * j + 64] = result[80 * j + 64] + 1;
                            break;
                        case "Q":
                            result[80 * j + 65] = result[80 * j + 65] + 1;
                            break;
                        case "E":
                            result[80 * j + 66] = result[80 * j + 66] + 1;
                            break;
                        case "G":
                            result[80 * j + 67] = result[80 * j + 67] + 1;
                            break;
                        case "H":
                            result[80 * j + 68] = result[80 * j + 68] + 1;
                            break;
                        case "I":
                            result[80 * j + 69] = result[80 * j + 69] + 1;
                            break;
                        case "L":
                            result[80 * j + 70] = result[80 * j + 70] + 1;
                            break;
                        case "K":
                            result[80 * j + 71] = result[80 * j + 71] + 1;
                            break;
                        case "M":
                            result[80 * j + 72] = result[80 * j + 72] + 1;
                            break;
                        case "F":
                            result[80 * j + 73] = result[80 * j + 73] + 1;
                            break;
                        case "P":
                            result[80 * j + 74] = result[80 * j + 74] + 1;
                            break;
                        case "S":
                            result[80 * j + 75] = result[80 * j + 75] + 1;
                            break;
                        case "T":
                            result[80 * j + 76] = result[80 * j + 76] + 1;
                            break;
                        case "W":
                            result[80 * j + 77] = result[80 * j + 77] + 1;
                            break;
                        case "Y":
                            result[80 * j + 78] = result[80 * j + 78] + 1;
                            break;
                        case "V":
                            result[80 * j + 79] = result[80 * j + 79] + 1;
                            break;
                    }
                }
            }

            //在新的一行追加数据在一个文件夹里
            string output_path = output_txt.Text.ToString() + "\\" + combo_box.SelectedItem.ToString().Substring(0, combo_box.SelectedItem.ToString().Length - 4) + "_1600.txt";
            StreamWriter sw = File.AppendText(output_path);
            for (int k = 0; k < 1600; k++)
            {
                if (k < 1599)
                    sw.Write(result[k] / rowSum + " ");
                if (k == 1599)
                    sw.Write(result[k] / rowSum + "\r\n");
            }
            sw.Flush();
            sw.Close();
            MessageBox.Show("Successfully generated！");
            OpenFolderAndSelectFile(output_path);
        }

        private void OpenFolderAndSelectFile(String fileFullName)
        {
            System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo("Explorer.exe");
            psi.Arguments = "/e,/select," + fileFullName;
            System.Diagnostics.Process.Start(psi);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                VisitLink3();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void VisitLink3()
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            string htmlPath = @"YNU/My Product Name/source/html/Read%20Me.html";
            string fullName = Application.StartupPath.Substring(0, Application.StartupPath.LastIndexOf("\\"));
            fullName = fullName.Substring(0, fullName.LastIndexOf("\\")) + "\\" + htmlPath;
            fullName = "file:///" + fullName.Replace("\\", "/");
            System.Diagnostics.Process.Start(fullName);
            //System.Diagnostics.Process.Start();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                VisitLink();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void VisitLink()
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            string htmlPath = @"YNU/My Product Name/source/html/citation.html";
            string fullName = Application.StartupPath.Substring(0, Application.StartupPath.LastIndexOf("\\"));
            fullName = fullName.Substring(0, fullName.LastIndexOf("\\")) + "\\" + htmlPath;
            fullName = "file:///" + fullName.Replace("\\", "/");
            System.Diagnostics.Process.Start(fullName);
            //System.Diagnostics.Process.Start("file:///C:/Users/caozi/Desktop/ico/citation.html");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                VisitLink1();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }

        private void VisitLink1()
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            string htmlPath = @"YNU/My Product Name/source/html/Benchmark%20Data.html";
            string fullName = Application.StartupPath.Substring(0, Application.StartupPath.LastIndexOf("\\"));
            fullName = fullName.Substring(0, fullName.LastIndexOf("\\")) + "\\" + htmlPath;
            fullName = "file:///" + fullName.Replace("\\", "/");
            System.Diagnostics.Process.Start(fullName);
            //System.Diagnostics.Process.Start("file:///C:/Users/caozi/Desktop/ico/Benchmark%20Data.html");
        }
    }
}
